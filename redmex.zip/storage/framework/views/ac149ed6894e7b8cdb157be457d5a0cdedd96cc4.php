<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
  <link rel="stylesheet"
    href="//fonts.googleapis.com/css2?family=Fira+Sans+Condensed:wght@300;400;500;700&family=Lato:wght@300;400;700&display=swap">

  <link rel="stylesheet" href="<?php echo e(asset('icons/fontawesome/css/all.min.css')); ?>"><!-- FontAwesome Icons -->
  <link rel="stylesheet" href="<?php echo e(asset('icons/dashicons/css/dashicons-min.css')); ?>"><!-- DashIcons For Star Ratings -->

  <title>Vayvo - Media Streaming &amp; Membership Site Template</title>
</head>

<body>
  <header id="masthead-pro" class="sticky-header">
    <!-- Remove sticky-header class to remove sticky header -->
    <div class="header-container">

      <a href="home.html" class="float-left mt-3 mx-3"><img src="<?php echo e(asset('images/chankro.png')); ?>" width="50" alt="Logo"></a>

      <nav id="site-navigation-pro">
        <ul class="sf-menu">
          <li class="normal-item-pro current-menu-item">
            <a href="home.html"><i class="fas fa-home"></i>Home</a>
          </li>
          <li class="normal-item-pro">
            <a href="tv-series.html"><i class="fas fa-tv"></i>TV Series</a>
            <!-- Sub-Menu Example >
       <ul class="sub-menu">
        <li class="normal-item-pro">
         <a href="#!">Sub-menu item 1</a>
        </li>
        <li class="normal-item-pro">
         <a href="#!">Sub-menu item 2</a>
        </li>
        <li class="normal-item-pro">
         <a href="#!">Sub-menu item 3</a>
        </li>
       </ul>
       < End Sub-Menu example -->
          </li>
          <li class="normal-item-pro">
            <a href="movies.html"><i class="fas fa-film"></i>Movies</a>
          </li>
          <li class="normal-item-pro">
            <a href="podcasts.html"><i class="fas fa-podcast"></i>Podcasts</a>
          </li>
          <li class="normal-item-pro">
            <a href="blog.html">Blog</a>
          </li>
        </ul>
      </nav>

      <!--div id="header-btn-right">
     <button class="btn btn-header-pro noselect" data-toggle="modal" data-target="#LoginModal" >Login</button>
    </div-->

      <div id="mobile-bars-icon-pro" class="noselect"><i class="fas fa-bars"></i></div>


      <div id="header-user-profile">
        <div id="header-user-profile-click" class="noselect">
          <img src="http://via.placeholder.com/80x80" alt="Suzie">
          <div id="header-username">Jane Doe</div><i class="fas fa-angle-down"></i>
        </div><!-- close #header-user-profile-click -->
        <div id="header-user-profile-menu">
          <ul>
            <li><a href="profile.html"><i class="fa fa-user-circle"></i>My Profile</a></li>
            <li><a href="#!"><i class="fa fa-cogs"></i>Edit Profile</a></li>
            <li><a href="profile.html"><i class="fa fa-list-ul"></i>My Watchlist</a></li>
            <li><a href="membership-plan.html"><i class="fa fa-credit-card"></i>Membership Plan</a></li>
            <li><a href="index.html"><i class="fa fa-power-off"></i>Log Out</a></li>
          </ul>
        </div><!-- close #header-user-profile-menu -->
      </div><!-- close #header-user-profile -->

      <div id="progression-studios-header-search-icon" class="noselect">
        <div class="progression-icon-search"></div>
      </div>


      <div id="video-search-header">
        <div class="container">

          <input type="text" placeholder="Search for Movies or TV Series" aria-label="Search" id="main-text-field">

          <div id="video-search-header-filtering">
            <form id="video-search-header-filtering-padding">
              <div class="row">
                <div class="col-sm extra-padding">
                  <div class="dotted-dividers-pro">
                    <h5>Type:</h5>
                    <ul class="video-search-type-list">
                      <li>
                        <label class="checkbox-pro-container">Movies
                          <input type="checkbox" checked="checked" id="movies-type">
                          <span class="checkmark-pro"></span>
                        </label>

                        <label class="checkbox-pro-container">TV Series
                          <input type="checkbox" id="tv-type">
                          <span class="checkmark-pro"></span>
                        </label>
                      </li>
                      <li>
                        <label class="checkbox-pro-container">New Arrivals
                          <input type="checkbox" id="movie-type">
                          <span class="checkmark-pro"></span>
                        </label>

                        <label class="checkbox-pro-container">Documentary
                          <input type="checkbox" id="documentary-type">
                          <span class="checkmark-pro"></span>
                        </label>
                      </li>
                    </ul>
                    <div class="clearfix"></div>

                  </div><!-- close .dotted-dividers-pro -->
                </div><!-- close .col -->
                <div class="col-sm extra-padding">
                  <div class="dotted-dividers-pro">
                    <h5>Genres:</h5>
                    <select class="custom-select">
                      <option selected>All Genres</option>
                      <option value="1">Action</option>
                      <option value="2">Adventure</option>
                      <option value="3">Drama</option>
                      <option value="4">Animation</option>
                      <option value="5">Documentary</option>
                      <option value="6">Drama</option>
                      <option value="7">Horror</option>
                      <option value="8">Thriller</option>
                      <option value="9">Fantasy</option>
                      <option value="10">Romance</option>
                      <option value="11">Sci-Fi</option>
                      <option value="12">Western</option>
                    </select>
                  </div><!-- close .dotted-dividers-pro -->
                </div><!-- close .col -->
                <div class="col-sm extra-padding">
                  <div class="dotted-dividers-pro">
                    <h5>Country:</h5>
                    <select class="custom-select">
                      <option selected>All Countries</option>
                      <option value="1">Argentina</option>
                      <option value="2">Australia</option>
                      <option value="3">Bahamas</option>
                      <option value="4">Belgium</option>
                      <option value="5">Brazil</option>
                      <option value="6">Canada</option>
                      <option value="7">Chile</option>
                      <option value="8">China</option>
                      <option value="9">Denmark</option>
                      <option value="10">Ecuador</option>
                      <option value="11">France</option>
                      <option value="12">Germany</option>
                      <option value="13">Greece</option>
                      <option value="14">Guatemala</option>
                      <option value="15">Italy</option>
                      <option value="16">Japan</option>
                      <option value="17">asdfasdf</option>
                      <option value="18">Korea</option>
                      <option value="19">Malaysia</option>
                      <option value="20">Monaco</option>
                      <option value="21">Morocco</option>
                      <option value="22">New Zealand</option>
                      <option value="23">Panama</option>
                      <option value="24">Portugal</option>
                      <option value="25">Russia</option>
                      <option value="26">United Kingdom</option>
                      <option value="27">United States</option>
                    </select>
                  </div><!-- close .dotted-dividers-pro -->
                </div><!-- close .col -->
                <div class="col-sm extra-padding extra-range-padding">
                  <h5>Average Rating:</h5>
                  <div class="range-padding-top"><input class="range-example-rating-input" type="text" min="0" max="10"
                      value="4,10" step="1" /></div>
                  <!-- JS is under /js/script.js -->
                </div><!-- close .col -->
              </div><!-- close .row -->
              <div id="video-search-header-buttons">
                <a href="#!" class="btn">Search Videos</a>
                <a href="#!" class="btn reset-btn">Reset</a>
              </div><!-- close #video-search-header-buttons -->
            </form><!-- #video-search-header-filtering-padding -->
          </div><!-- close #video-search-header-filtering -->

        </div><!-- close .container -->
      </div><!-- close .video-search-header -->



      <div class="clearfix"></div>
    </div><!-- close .header-container -->

    <nav id="mobile-navigation-pro">

      <ul id="mobile-menu-pro">
        <li>
          <a href="home.html"><i class="fas fa-home"></i>Home</a>
        </li>
        <li>
          <a href="tv-series.html"><i class="fas fa-tv"></i>TV Series</a>
          <!-- Sub-Menu Example >
      <ul class="sub-menu">
       <li>
        <a href="#!">Sub-menu item 1</a>
       </li>
       <li>
        <a href="#!">Sub-menu item 2</a>
       </li>
       <li>
        <a href="#!">Sub-menu item 3</a>
       </li>
      </ul>
      < End Sub-Menu example -->
        </li>
        <li>
          <a href="movies.html"><i class="fas fa-film"></i>Movies</a>
        </li>
        <li>
          <a href="podcasts.html"><i class="fas fa-podcast"></i>Podcasts</a>
        </li>
        <li>
          <a href="blog.html">Blog</a>
        </li>

      </ul>
      <!--button class="btn btn-mobile-pro btn-header-pro noselect" data-toggle="modal" data-target="#LoginModal" >Login</button-->

      <div id="search-mobile-nav-pro">
        <input type="text" placeholder="Search for Movies or TV Series" aria-label="Search">
      </div>

    </nav>
    <div id="progression-studios-header-shadow"></div>
  </header>

  <div class="flexslider progression-studios-slider">
    <ul class="slides">
      <li class="progression_studios_animate_left">
        <div class="progression-studios-slider-image-background"
          style="background-image:url(http://via.placeholder.com/1700x1133);">
          <div class="progression-studios-slider-display-table">
            <div class="progression-studios-slider-vertical-align">

              <div class="container">

                <div class="progression-studios-slider-caption-width">
                  <div class="progression-studios-slider-caption-align">
                    <h2><a href="video-post.html">Blue Surf</a></h2>
                    <ul class="slider-video-post-meta-list">
                      <li class="slider-video-post-meta-cat">
                        <ul>
                          <li><a href="#!">Drama</a></li>
                        </ul>
                      </li>
                      <li class="slider-video-post-meta-reviews">
                        <div class="average-rating-video-post">
                          <div class="average-rating-video-empty">
                            <span class="dashicons dashicons-star-empty"></span><span
                              class="dashicons dashicons-star-empty"></span><span
                              class="dashicons dashicons-star-empty"></span><span
                              class="dashicons dashicons-star-empty"></span><span
                              class="dashicons dashicons-star-empty"></span>
                          </div>
                          <div class="average-rating-overflow-width" style="width:80%;">
                            <div class="average-rating-video-filled">
                              <span class="dashicons dashicons-star-filled"></span><span
                                class="dashicons dashicons-star-filled"></span><span
                                class="dashicons dashicons-star-filled"></span><span
                                class="dashicons dashicons-star-filled"></span><span
                                class="dashicons dashicons-star-filled"></span>
                              <div class="clearfix"></div>
                            </div><!-- close .average-rating-video-filled -->
                          </div><!-- close .average-rating-overflow-width -->
                        </div><!-- close .average-rating-video-post -->
                        <div class="clearfix"></div>
                      </li>
                      <li class="slider-video-post-meta-year">2019</li>
                      <li class="slider-video-post-meta-rating"><span>PG-13</span></li>
                    </ul>
                    <div class="clearfix"></div>
                    <div class="progression-studios-slider-excerpt">Mae Holland seizes the opportunity of a lifetime
                      when she lands a job with the world’s most powerful technology and social media company.</div>
                    <a class="btn btn-slider-pro afterglow" href="#VideoLightbox-1"><i
                        class="fas fa-play-circle"></i>Watch Now</a>

                    <video id="VideoLightbox-1" poster="http://via.placeholder.com/960x540" width="960" height="540">
                      <source src="<?php echo e(asset('images/video/sample.mp4')); ?>" type="video/mp4">
                    </video>

                  </div><!-- close .progression-studios-slider-caption-align -->
                </div><!-- close .progression-studios-slider-caption-width -->

              </div><!-- close .container -->

            </div><!-- close .progression-studios-slider-vertical-align -->
          </div><!-- close .progression-studios-slider-display-table -->

          <div class="progression-studios-slider-overlay-gradient"></div>

          <div class="progression-studios-skrn-slider-upside-down"
            style="background-image:url(http://via.placeholder.com/1700x1133);"></div>


        </div><!-- close .progression-studios-slider-image-background -->
      </li>
      <li class="progression_studios_animate_in">
        <div class="progression-studios-slider-image-background"
          style="background-image:url(http://via.placeholder.com/1700x1133);">
          <div class="progression-studios-slider-display-table">
            <div class="progression-studios-slider-vertical-align">

              <div class="container">

                <div class="progression-studios-slider-caption-width">
                  <div class="progression-studios-slider-caption-align">
                    <h2><a href="video-post.html">Grand Tour</a></h2>
                    <ul class="slider-video-post-meta-list">
                      <li class="slider-video-post-meta-cat">
                        <ul>
                          <li><a href="#!">Action</a></li>
                        </ul>
                      </li>
                      <li class="slider-video-post-meta-reviews">
                        <div class="average-rating-video-post">
                          <div class="average-rating-video-empty">
                            <span class="dashicons dashicons-star-empty"></span><span
                              class="dashicons dashicons-star-empty"></span><span
                              class="dashicons dashicons-star-empty"></span><span
                              class="dashicons dashicons-star-empty"></span><span
                              class="dashicons dashicons-star-empty"></span>
                          </div>
                          <div class="average-rating-overflow-width" style="width:90%;">
                            <div class="average-rating-video-filled">
                              <span class="dashicons dashicons-star-filled"></span><span
                                class="dashicons dashicons-star-filled"></span><span
                                class="dashicons dashicons-star-filled"></span><span
                                class="dashicons dashicons-star-filled"></span><span
                                class="dashicons dashicons-star-filled"></span>
                              <div class="clearfix"></div>
                            </div><!-- close .average-rating-video-filled -->
                          </div><!-- close .average-rating-overflow-width -->
                        </div><!-- close .average-rating-video-post -->
                        <div class="clearfix"></div>
                      </li>
                      <li class="slider-video-post-meta-year">2018</li>
                      <li class="slider-video-post-meta-rating"><span>TV-MA</span></li>
                    </ul>
                    <div class="clearfix"></div>
                    <div class="progression-studios-slider-excerpt">The Tour de France is an annual men’s multiple
                      stage
                      bicycle race primarily held in France, while also occasionally passing through nearby countries.
                    </div>
                    <a class="btn btn-slider-pro afterglow" href="#VideoLightbox-2"><i
                        class="fas fa-play-circle"></i>Watch Trailer</a>

                    <video id="VideoLightbox-2" poster="http://via.placeholder.com/960x540" width="960" height="540">
                      <source src="<?php echo e(asset('images/video/sample.mp4')); ?>" type="video/mp4">
                    </video>

                  </div><!-- close .progression-studios-slider-caption-align -->
                </div><!-- close .progression-studios-slider-caption-width -->

              </div><!-- close .container -->

            </div><!-- close .progression-studios-slider-vertical-align -->
          </div><!-- close .progression-studios-slider-display-table -->

          <div class="progression-studios-slider-overlay-gradient"></div>

          <div class="progression-studios-skrn-slider-upside-down"
            style="background-image:url(http://via.placeholder.com/1700x1133);"></div>


        </div><!-- close .progression-studios-slider-image-background -->
      </li>
      <li class="progression_studios_animate_right">
        <div class="progression-studios-slider-image-background"
          style="background-image:url(http://via.placeholder.com/1700x1133);">
          <div class="progression-studios-slider-display-table">
            <div class="progression-studios-slider-vertical-align">

              <div class="container">

                <div class="progression-studios-slider-caption-width">
                  <div class="progression-studios-slider-caption-align">
                    <h2><a href="video-post.html">Fast &amp; Furious</a></h2>
                    <ul class="slider-video-post-meta-list">
                      <li class="slider-video-post-meta-cat">
                        <ul>
                          <li><a href="#!">Action</a></li>
                        </ul>
                      </li>
                      <li class="slider-video-post-meta-reviews">
                        <div class="average-rating-video-post">
                          <div class="average-rating-video-empty">
                            <span class="dashicons dashicons-star-empty"></span><span
                              class="dashicons dashicons-star-empty"></span><span
                              class="dashicons dashicons-star-empty"></span><span
                              class="dashicons dashicons-star-empty"></span><span
                              class="dashicons dashicons-star-empty"></span>
                          </div>
                          <div class="average-rating-overflow-width" style="width:90%;">
                            <div class="average-rating-video-filled">
                              <span class="dashicons dashicons-star-filled"></span><span
                                class="dashicons dashicons-star-filled"></span><span
                                class="dashicons dashicons-star-filled"></span><span
                                class="dashicons dashicons-star-filled"></span><span
                                class="dashicons dashicons-star-filled"></span>
                              <div class="clearfix"></div>
                            </div><!-- close .average-rating-video-filled -->
                          </div><!-- close .average-rating-overflow-width -->
                        </div><!-- close .average-rating-video-post -->
                        <div class="clearfix"></div>
                      </li>
                      <li class="slider-video-post-meta-year">2018</li>
                      <li class="slider-video-post-meta-rating"><span>PG-13</span></li>
                    </ul>
                    <div class="clearfix"></div>
                    <div class="progression-studios-slider-excerpt">Mae Holland seizes the opportunity of a lifetime
                      when she lands a job with the world’s most powerful technology and social media company.</div>
                    <a class="btn btn-slider-pro afterglow" href="#VideoLightbox-3"><i
                        class="fas fa-play-circle"></i>Watch Now</a>

                    <video id="VideoLightbox-3" poster="http://via.placeholder.com/960x540" width="960" height="540">
                      <source src="<?php echo e(asset('images/video/sample.mp4')); ?>" type="video/mp4">
                    </video>

                  </div><!-- close .progression-studios-slider-caption-align -->
                </div><!-- close .progression-studios-slider-caption-width -->

              </div><!-- close .container -->

            </div><!-- close .progression-studios-slider-vertical-align -->
          </div><!-- close .progression-studios-slider-display-table -->

          <div class="progression-studios-slider-overlay-gradient"></div>

          <div class="progression-studios-skrn-slider-upside-down"
            style="background-image:url(http://via.placeholder.com/1700x1133);"></div>


        </div><!-- close .progression-studios-slider-image-background -->
      </li>
    </ul>
  </div><!-- close .progression-studios-slider - See /js/script.js file for options -->

  <div id="content-pro">

    <div class="container custom-gutters-pro">

      <div style="height:15px;"></div>

      <h2 class="post-list-heading">Featured<span>These Picks Won't Disappoint</span></h2>


      <div class="progression-studios-elementor-carousel-container progression-studios-always-arrows-on">
        <div id="progression-video-carousel" class="owl-carousel progression-carousel-theme">

          <div class="item">
            <div class="progression-studios-video-index-container">
              <a href="video-post.html">
                <div class="progression-studios-video-feaured-image"><img src="http://via.placeholder.com/700x480"
                    alt="Featured Image"></div>

                <div class="progression-video-index-content">
                  <div class="progression-video-index-table">
                    <div class="progression-video-index-vertical-align">

                      <h2 class="progression-video-title">Space Time</h2>

                      <div class="average-rating-video-post">
                        <div class="average-rating-video-empty">
                          <span class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span>
                        </div>
                        <div class="average-rating-overflow-width" style="width:100%;">
                          <div class="average-rating-video-filled">
                            <span class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span>
                            <div class="clearfix"></div>
                          </div><!-- close .average-rating-video-filled -->
                        </div><!-- close .average-rating-overflow-width -->
                      </div><!-- close .average-rating-video-post -->
                      <div class="clearfix"></div>

                      <ul class="video-index-meta-taxonomy">
                        <li>Sci-fi</li>
                      </ul>
                      <div class="clearfix"></div>

                    </div><!-- close .progression-video-index-vertical-align -->
                  </div><!-- close .progression-video-index-table -->
                </div><!-- close .progression-video-index-content -->
                <div class="video-index-border-hover"></div>

              </a>
            </div><!-- close .progression-studios-video-index-container  -->
          </div><!-- close .item -->

          <div class="item">
            <div class="progression-studios-video-index-container">
              <a href="video-post.html">

                <div class="progression-studios-video-feaured-image"><img src="http://via.placeholder.com/700x480"
                    alt="Featured Image"></div>

                <div class="progression-video-index-content">
                  <div class="progression-video-index-table">
                    <div class="progression-video-index-vertical-align">

                      <h2 class="progression-video-title">The Dark Tower</h2>

                      <div class="average-rating-video-post">
                        <div class="average-rating-video-empty">
                          <span class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span>
                        </div>
                        <div class="average-rating-overflow-width" style="width:70%;">
                          <div class="average-rating-video-filled">
                            <span class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span>
                            <div class="clearfix"></div>
                          </div><!-- close .average-rating-video-filled -->
                        </div><!-- close .average-rating-overflow-width -->
                      </div><!-- close .average-rating-video-post -->
                      <div class="clearfix"></div>

                      <ul class="video-index-meta-taxonomy">
                        <li>Sci-fi</li>
                      </ul>
                      <div class="clearfix"></div>

                    </div><!-- close .progression-video-index-vertical-align -->
                  </div><!-- close .progression-video-index-table -->
                </div><!-- close .progression-video-index-content -->
                <div class="video-index-border-hover"></div>

              </a>
            </div><!-- close .progression-studios-video-index-container -->
          </div><!-- close .item -->


          <div class="item">
            <div class="progression-studios-video-index-container">
              <a href="video-post.html">

                <div class="progression-studios-video-feaured-image"><img src="http://via.placeholder.com/700x480"
                    alt="Featured Image"></div>

                <div class="progression-video-index-content">
                  <div class="progression-video-index-table">
                    <div class="progression-video-index-vertical-align">

                      <h2 class="progression-video-title">Designing for the Future</h2>

                      <div class="average-rating-video-post">
                        <div class="average-rating-video-empty">
                          <span class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span>
                        </div>
                        <div class="average-rating-overflow-width" style="width:80%;">
                          <div class="average-rating-video-filled">
                            <span class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span>
                            <div class="clearfix"></div>
                          </div><!-- close .average-rating-video-filled -->
                        </div><!-- close .average-rating-overflow-width -->
                      </div><!-- close .average-rating-video-post -->
                      <div class="clearfix"></div>

                      <ul class="video-index-meta-taxonomy">
                        <li>Sci-fi</li>
                      </ul>
                      <div class="clearfix"></div>

                    </div><!-- close .progression-video-index-vertical-align -->
                  </div><!-- close .progression-video-index-table -->
                </div><!-- close .progression-video-index-content -->
                <div class="video-index-border-hover"></div>

              </a>
            </div><!-- close .progression-studios-video-index-container -->
          </div><!-- close .item -->

          <div class="item">
            <div class="progression-studios-video-index-container">
              <a href="video-post.html">

                <div class="progression-studios-video-feaured-image"><img src="http://via.placeholder.com/700x480"
                    alt="Featured Image"></div>

                <div class="progression-video-index-content">
                  <div class="progression-video-index-table">
                    <div class="progression-video-index-vertical-align">

                      <h2 class="progression-video-title">Art of Flight</h2>

                      <div class="average-rating-video-post">
                        <div class="average-rating-video-empty">
                          <span class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span>
                        </div>
                        <div class="average-rating-overflow-width" style="width:90%;">
                          <div class="average-rating-video-filled">
                            <span class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span>
                            <div class="clearfix"></div>
                          </div><!-- close .average-rating-video-filled -->
                        </div><!-- close .average-rating-overflow-width -->
                      </div><!-- close .average-rating-video-post -->
                      <div class="clearfix"></div>

                      <ul class="video-index-meta-taxonomy">
                        <li>Action</li>
                      </ul>
                      <div class="clearfix"></div>

                    </div><!-- close .progression-video-index-vertical-align -->
                  </div><!-- close .progression-video-index-table -->
                </div><!-- close .progression-video-index-content -->
                <div class="video-index-border-hover"></div>

              </a>
            </div><!-- close .progression-studios-video-index-container -->
          </div><!-- close .item -->


          <div class="item">
            <div class="progression-studios-video-index-container">
              <a href="video-post.html">

                <div class="progression-studios-video-feaured-image"><img src="http://via.placeholder.com/700x480"
                    alt="Featured Image"></div>

                <div class="progression-video-index-content">
                  <div class="progression-video-index-table">
                    <div class="progression-video-index-vertical-align">

                      <h2 class="progression-video-title">Parts Unkown</h2>

                      <div class="average-rating-video-post">
                        <div class="average-rating-video-empty">
                          <span class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span><span
                            class="dashicons dashicons-star-empty"></span>
                        </div>
                        <div class="average-rating-overflow-width" style="width:50%;">
                          <div class="average-rating-video-filled">
                            <span class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span><span
                              class="dashicons dashicons-star-filled"></span>
                            <div class="clearfix"></div>
                          </div><!-- close .average-rating-video-filled -->
                        </div><!-- close .average-rating-overflow-width -->
                      </div><!-- close .average-rating-video-post -->
                      <div class="clearfix"></div>

                      <ul class="video-index-meta-taxonomy">
                        <li>Action, Drama</li>
                      </ul>
                      <div class="clearfix"></div>

                    </div><!-- close .progression-video-index-vertical-align -->
                  </div><!-- close .progression-video-index-table -->
                </div><!-- close .progression-video-index-content -->
                <div class="video-index-border-hover"></div>

              </a>
            </div><!-- close .progression-studios-video-index-container -->
          </div><!-- close .item -->

        </div><!-- close #progression-video-carousel - See /js/script.js file for options -->
      </div><!-- close .progression-studios-elementor-carousel-container  -->

      <div class="clearfix"></div>



      <div style="height:85px;"></div>

      <h2 class="post-list-heading">New Arrivals<span>Find Something New to Watch</span></h2>

      <div class="row">

        <div class="col col-12 col-md-6 col-lg-4">
          <div class="progression-studios-video-index-container">
            <a href="video-post.html">
              <div class="progression-studios-video-feaured-image"><img src="http://via.placeholder.com/700x480"
                  alt="Featured Image"></div>

              <div class="progression-video-index-content">
                <div class="progression-video-index-table">
                  <div class="progression-video-index-vertical-align">

                    <h2 class="progression-video-title">Planet Earth</h2>

                    <div class="average-rating-video-post">
                      <div class="average-rating-video-empty">
                        <span class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span>
                      </div>
                      <div class="average-rating-overflow-width" style="width:70%;">
                        <div class="average-rating-video-filled">
                          <span class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span>
                          <div class="clearfix"></div>
                        </div><!-- close .average-rating-video-filled -->
                      </div><!-- close .average-rating-overflow-width -->
                    </div><!-- close .average-rating-video-post -->
                    <div class="clearfix"></div>

                    <ul class="video-index-meta-taxonomy">
                      <li>Drama</li>
                    </ul>
                    <div class="clearfix"></div>

                  </div><!-- close .progression-video-index-vertical-align -->
                </div><!-- close .progression-video-index-table -->
              </div><!-- close .progression-video-index-content -->
              <div class="video-index-border-hover"></div>

            </a>
          </div><!-- close .progression-studios-video-index-container -->
        </div><!-- close .col -->

        <div class="col col-12 col-md-6 col-lg-4">
          <div class="progression-studios-video-index-container">
            <a href="video-post.html">

              <div class="progression-studios-video-feaured-image"><img src="http://via.placeholder.com/700x480"
                  alt="Featured Image"></div>

              <div class="progression-video-index-content">
                <div class="progression-video-index-table">
                  <div class="progression-video-index-vertical-align">

                    <h2 class="progression-video-title">Polar Express</h2>

                    <div class="average-rating-video-post">
                      <div class="average-rating-video-empty">
                        <span class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span>
                      </div>
                      <div class="average-rating-overflow-width" style="width:90%;">
                        <div class="average-rating-video-filled">
                          <span class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span>
                          <div class="clearfix"></div>
                        </div><!-- close .average-rating-video-filled -->
                      </div><!-- close .average-rating-overflow-width -->
                    </div><!-- close .average-rating-video-post -->
                    <div class="clearfix"></div>

                    <ul class="video-index-meta-taxonomy">
                      <li>Sci-fi</li>
                    </ul>
                    <div class="clearfix"></div>

                  </div><!-- close .progression-video-index-vertical-align -->
                </div><!-- close .progression-video-index-table -->
              </div><!-- close .progression-video-index-content -->
              <div class="video-index-border-hover"></div>

            </a>
          </div><!-- close .progression-studios-video-index-container -->
        </div><!-- close .col -->

        <div class="col col-12 col-md-6 col-lg-4">
          <div class="progression-studios-video-index-container">
            <a href="video-post.html">

              <div class="progression-studios-video-feaured-image"><img src="http://via.placeholder.com/700x480"
                  alt="Featured Image"></div>

              <div class="progression-video-index-content">
                <div class="progression-video-index-table">
                  <div class="progression-video-index-vertical-align">

                    <h2 class="progression-video-title">World's Busiest City</h2>

                    <div class="average-rating-video-post">
                      <div class="average-rating-video-empty">
                        <span class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span>
                      </div>
                      <div class="average-rating-overflow-width" style="width:60%;">
                        <div class="average-rating-video-filled">
                          <span class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span>
                          <div class="clearfix"></div>
                        </div><!-- close .average-rating-video-filled -->
                      </div><!-- close .average-rating-overflow-width -->
                    </div><!-- close .average-rating-video-post -->
                    <div class="clearfix"></div>

                    <ul class="video-index-meta-taxonomy">
                      <li>Action</li>
                    </ul>
                    <div class="clearfix"></div>

                  </div><!-- close .progression-video-index-vertical-align -->
                </div><!-- close .progression-video-index-table -->
              </div><!-- close .progression-video-index-content -->
              <div class="video-index-border-hover"></div>

            </a>
          </div><!-- close .progression-studios-video-index-container -->
        </div><!-- close .col -->

        <div class="col col-12 col-md-6 col-lg-4">
          <div class="progression-studios-video-index-container">
            <a href="video-post.html">
              <div class="progression-studios-video-feaured-image"><img src="http://via.placeholder.com/700x480"
                  alt="Featured Image"></div>

              <div class="progression-video-index-content">
                <div class="progression-video-index-table">
                  <div class="progression-video-index-vertical-align">

                    <h2 class="progression-video-title">South Pacific</h2>

                    <div class="average-rating-video-post">
                      <div class="average-rating-video-empty">
                        <span class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span>
                      </div>
                      <div class="average-rating-overflow-width" style="width:100%;">
                        <div class="average-rating-video-filled">
                          <span class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span>
                          <div class="clearfix"></div>
                        </div><!-- close .average-rating-video-filled -->
                      </div><!-- close .average-rating-overflow-width -->
                    </div><!-- close .average-rating-video-post -->
                    <div class="clearfix"></div>

                    <ul class="video-index-meta-taxonomy">
                      <li>Drama</li>
                    </ul>
                    <div class="clearfix"></div>

                  </div><!-- close .progression-video-index-vertical-align -->
                </div><!-- close .progression-video-index-table -->
              </div><!-- close .progression-video-index-content -->
              <div class="video-index-border-hover"></div>

            </a>
          </div><!-- close .progression-studios-video-index-container -->
        </div><!-- close .col -->

        <div class="col col-12 col-md-6 col-lg-4">
          <div class="progression-studios-video-index-container">
            <a href="video-post.html">

              <div class="progression-studios-video-feaured-image"><img src="http://via.placeholder.com/700x480"
                  alt="Featured Image"></div>

              <div class="progression-video-index-content">
                <div class="progression-video-index-table">
                  <div class="progression-video-index-vertical-align">

                    <h2 class="progression-video-title">Mad Profit</h2>

                    <div class="average-rating-video-post">
                      <div class="average-rating-video-empty">
                        <span class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span>
                      </div>
                      <div class="average-rating-overflow-width" style="width:90%;">
                        <div class="average-rating-video-filled">
                          <span class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span>
                          <div class="clearfix"></div>
                        </div><!-- close .average-rating-video-filled -->
                      </div><!-- close .average-rating-overflow-width -->
                    </div><!-- close .average-rating-video-post -->
                    <div class="clearfix"></div>

                    <ul class="video-index-meta-taxonomy">
                      <li>Drama</li>
                    </ul>
                    <div class="clearfix"></div>

                  </div><!-- close .progression-video-index-vertical-align -->
                </div><!-- close .progression-video-index-table -->
              </div><!-- close .progression-video-index-content -->
              <div class="video-index-border-hover"></div>

            </a>
          </div><!-- close .progression-studios-video-index-container -->
        </div><!-- close .col -->

        <div class="col col-12 col-md-6 col-lg-4">
          <div class="progression-studios-video-index-container">
            <a href="video-post.html">

              <div class="progression-studios-video-feaured-image"><img src="http://via.placeholder.com/700x480"
                  alt="Featured Image"></div>

              <div class="progression-video-index-content">
                <div class="progression-video-index-table">
                  <div class="progression-video-index-vertical-align">

                    <h2 class="progression-video-title">Geostorm</h2>

                    <div class="average-rating-video-post">
                      <div class="average-rating-video-empty">
                        <span class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span>
                      </div>
                      <div class="average-rating-overflow-width" style="width:50%;">
                        <div class="average-rating-video-filled">
                          <span class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span>
                          <div class="clearfix"></div>
                        </div><!-- close .average-rating-video-filled -->
                      </div><!-- close .average-rating-overflow-width -->
                    </div><!-- close .average-rating-video-post -->
                    <div class="clearfix"></div>

                    <ul class="video-index-meta-taxonomy">
                      <li>Sci-fi</li>
                    </ul>
                    <div class="clearfix"></div>

                  </div><!-- close .progression-video-index-vertical-align -->
                </div><!-- close .progression-video-index-table -->
              </div><!-- close .progression-video-index-content -->
              <div class="video-index-border-hover"></div>

            </a>
          </div><!-- close .progression-studios-video-index-container -->
        </div><!-- close .col -->


        <div class="col col-12 col-md-6 col-lg-4">
          <div class="progression-studios-video-index-container">
            <a href="video-post.html">
              <div class="progression-studios-video-feaured-image"><img src="http://via.placeholder.com/700x480"
                  alt="Featured Image"></div>

              <div class="progression-video-index-content">
                <div class="progression-video-index-table">
                  <div class="progression-video-index-vertical-align">

                    <h2 class="progression-video-title">Space Time</h2>

                    <div class="average-rating-video-post">
                      <div class="average-rating-video-empty">
                        <span class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span>
                      </div>
                      <div class="average-rating-overflow-width" style="width:100%;">
                        <div class="average-rating-video-filled">
                          <span class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span>
                          <div class="clearfix"></div>
                        </div><!-- close .average-rating-video-filled -->
                      </div><!-- close .average-rating-overflow-width -->
                    </div><!-- close .average-rating-video-post -->
                    <div class="clearfix"></div>

                    <ul class="video-index-meta-taxonomy">
                      <li>Sci-fi</li>
                    </ul>
                    <div class="clearfix"></div>

                  </div><!-- close .progression-video-index-vertical-align -->
                </div><!-- close .progression-video-index-table -->
              </div><!-- close .progression-video-index-content -->
              <div class="video-index-border-hover"></div>

            </a>
          </div><!-- close .progression-studios-video-index-container -->
        </div><!-- close .col -->

        <div class="col col-12 col-md-6 col-lg-4">
          <div class="progression-studios-video-index-container">
            <a href="video-post.html">

              <div class="progression-studios-video-feaured-image"><img src="http://via.placeholder.com/700x480"
                  alt="Featured Image"></div>

              <div class="progression-video-index-content">
                <div class="progression-video-index-table">
                  <div class="progression-video-index-vertical-align">

                    <h2 class="progression-video-title">Bloodline</h2>

                    <div class="average-rating-video-post">
                      <div class="average-rating-video-empty">
                        <span class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span>
                      </div>
                      <div class="average-rating-overflow-width" style="width:90%;">
                        <div class="average-rating-video-filled">
                          <span class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span>
                          <div class="clearfix"></div>
                        </div><!-- close .average-rating-video-filled -->
                      </div><!-- close .average-rating-overflow-width -->
                    </div><!-- close .average-rating-video-post -->
                    <div class="clearfix"></div>

                    <ul class="video-index-meta-taxonomy">
                      <li>Sci-fi</li>
                    </ul>
                    <div class="clearfix"></div>

                  </div><!-- close .progression-video-index-vertical-align -->
                </div><!-- close .progression-video-index-table -->
              </div><!-- close .progression-video-index-content -->
              <div class="video-index-border-hover"></div>

            </a>
          </div><!-- close .progression-studios-video-index-container -->
        </div><!-- close .col -->

        <div class="col col-12 col-md-6 col-lg-4">
          <div class="progression-studios-video-index-container">
            <a href="video-post.html">

              <div class="progression-studios-video-feaured-image"><img src="http://via.placeholder.com/700x480"
                  alt="Featured Image"></div>

              <div class="progression-video-index-content">
                <div class="progression-video-index-table">
                  <div class="progression-video-index-vertical-align">

                    <h2 class="progression-video-title">The Dark Tower</h2>

                    <div class="average-rating-video-post">
                      <div class="average-rating-video-empty">
                        <span class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span><span
                          class="dashicons dashicons-star-empty"></span>
                      </div>
                      <div class="average-rating-overflow-width" style="width:70%;">
                        <div class="average-rating-video-filled">
                          <span class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span><span
                            class="dashicons dashicons-star-filled"></span>
                          <div class="clearfix"></div>
                        </div><!-- close .average-rating-video-filled -->
                      </div><!-- close .average-rating-overflow-width -->
                    </div><!-- close .average-rating-video-post -->
                    <div class="clearfix"></div>

                    <ul class="video-index-meta-taxonomy">
                      <li>Sci-fi</li>
                    </ul>
                    <div class="clearfix"></div>

                  </div><!-- close .progression-video-index-vertical-align -->
                </div><!-- close .progression-video-index-table -->
              </div><!-- close .progression-video-index-content -->
              <div class="video-index-border-hover"></div>

            </a>
          </div><!-- close .progression-studios-video-index-container -->
        </div><!-- close .col -->

      </div><!-- close .row -->


      <ul class="page-numbers">
        <li><a class="previous" href="#!"><i class="fas fa-chevron-left"></i></a></li>
        <li><a class="current" href="#!">1</a></li>
        <li><a href="#!">2</a></li>
        <li><a href="#!">3</a></li>
        <li><a href="#!">4</a></li>
        <li><a class="next page-numbers-select" href="#!"><i class="fas fa-chevron-right"></i></a></li>
      </ul>


      <div class="clearfix"></div>
    </div><!-- close .container -->



  </div><!-- close #content-pro -->

  <footer id="footer-pro">
    <div class="container">
      <div class="row">
        <div class="col-md">
          <div class="copyright-text-pro">&copy; All rights reserved. Developed by <a href="#!">YourCompanyName</a>.
          </div>
        </div><!-- close .col -->
        <div class="col-md">
          <ul class="social-icons-pro">
            <li class="facebook-color"><a href="http://facebook.com/progressionstudios" target="_blank"><i
                  class="fab fa-facebook-f"></i></a></li>
            <li class="twitter-color"><a href="http://twitter.com/Progression_S" target="_blank"><i
                  class="fab fa-twitter"></i></a></li>
            <li class="instagram-color"><a href="http://instagram.com/" target="_blank"><i
                  class="fab fa-instagram"></i></a></li>
            <li class="youtube-color"><a href="http://youtube.com" target="_blank"><i class="fab fa-youtube"></i></a>
            </li>
            <li class="vimeo-color"><a href="http://vimeo.com" target="_blank"><i class="fab fa-vimeo-v"></i></a>
            </li>
          </ul>
        </div><!-- close .col -->
      </div><!-- close .row -->
    </div><!-- close .container -->
  </footer>

  <a href="#0" id="pro-scroll-top"><i class="fas fa-chevron-up"></i></a>


  <!-- Modal -->
  <div class="modal fade" id="LoginModal" tabindex="-1" role="dialog" aria-labelledby="LoginModal"
    aria-hidden="true">
    <button type="button" class="close float-close-pro noselect" data-dismiss="modal" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
      <div class="modal-content">
        <div class="modal-header-pro">
          <h2>Please login</h2>
        </div>
        <div class="modal-body-pro social-login-modal-body-pro">

          <div class="registration-login-container">
            <form>
              <div class="form-group">
                <input type="text" class="form-control" id="username" placeholder="Username">
              </div>
              <div class="form-group">
                <input type="password" class="form-control" id="password" placeholder="Password">
              </div>
              <div class="container-fluid">
                <div class="row no-gutters">
                  <div class="col checkbox-remember-pro"><input type="checkbox" id="checkbox-remember"><label
                      for="checkbox-remember" class="col-form-label">Remember me</label></div>
                  <div class="col forgot-your-password"><a href="#!">Forgot your password?</a></div>
                </div>
              </div><!-- close .container-fluid -->
              <div class="form-group aligncenter">
                <button type="button" class="btn">Login</button>
              </div>

              <div class="aligncenter"><a class="not-a-member-pro" href="landing-pricing-plans.html">Don't have
                  account? <span>Signup</span></a></div>



            </form>

          </div><!-- close .registration-login-container -->

        </div><!-- close .modal-body -->

      </div><!-- close .modal-content -->
    </div><!-- close .modal-dialog -->
  </div><!-- close .modal -->


  <!-- Required Framework JavaScript -->
  <script src="<?php echo e(asset('js/libs/jquery-3.5.1.min.js')); ?>"></script><!-- jQuery -->
  <script src="<?php echo e(asset('js/libs/popper.min.js')); ?>" defer></script><!-- Bootstrap Popper/Extras JS -->
  <script src="<?php echo e(asset('js/libs/bootstrap.min.js')); ?>" defer></script><!-- Bootstrap Main JS -->
  <!-- All JavaScript in Footer -->

  <!-- Additional Plugins and JavaScript -->
  <script src="<?php echo e(asset('js/navigation.js')); ?>" defer></script><!-- Header Navigation JS Plugin -->
  <script src="<?php echo e(asset('js/jquery.flexslider-min.js')); ?>" defer></script><!-- FlexSlider JS Plugin -->
  <script src="<?php echo e(asset('js/jquery-asRange.min.js')); ?>" defer></script><!-- Range Slider JS Plugin -->
  <script src="<?php echo e(asset('js/afterglow.min.js')); ?>" defer></script><!-- Video Player JS Plugin -->
  <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>" defer></script><!-- Carousel JS Plugin -->
  <script src="<?php echo e(asset('js/scripts.js')); ?>" defer></script><!-- Custom Document Ready JS -->


</body>

</html>
<?php /**PATH /home/juan/Documents/web/redmex/resources/views/app.blade.php ENDPATH**/ ?>